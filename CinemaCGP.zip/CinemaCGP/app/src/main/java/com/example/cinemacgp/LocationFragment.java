package com.example.cinemacgp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class LocationFragment extends Fragment {

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_map, container, false);
        SupportMapFragment supportMapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        supportMapFragment.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(@NonNull GoogleMap googleMap) {

                MarkerOptions markerOptions = new MarkerOptions();
                LatLng alpha = new LatLng(-6.193924061113853, 106.78813220277623);
                googleMap.addMarker(new MarkerOptions().position(alpha).title("Cinema CGP Alpha"));

                LatLng beta = new LatLng(-6.20175020412279, 106.78223868546155);
                googleMap.addMarker(new MarkerOptions().position(beta).title("Cinema CGP Beta"));

                LatLng zoom = new LatLng(-6.2, 106.78555);
                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(zoom, 15));
            }
        });
        return view;
    }
}