package com.example.cinemacgp;

import java.io.Serializable;

public class Movie implements Serializable {
    String title, img;

    public Movie() {}

    public String getTitle() {
        return title;
    }

    public void setName(String title) {
        this.title = title;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }
}
