package com.example.cinemacgp;

public class Ticket {
    private Movie movie;
    private String date, location;

    public Ticket(Movie movie, String date, String location) {
        this.movie = movie;
        this.date = date;
        this.location = location;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
