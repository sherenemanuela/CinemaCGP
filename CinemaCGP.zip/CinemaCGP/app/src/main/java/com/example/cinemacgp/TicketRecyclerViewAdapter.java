package com.example.cinemacgp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class TicketRecyclerViewAdapter extends RecyclerView.Adapter<TicketRecyclerViewAdapter.ViewHolder> {
    private Context context;
    private ArrayList<Ticket> tickets;

    public TicketRecyclerViewAdapter(Context context, ArrayList<Ticket> tickets) {
        this.context = context;
        this.tickets = tickets;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.ticket_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.title.setText(tickets.get(position).getMovie().getTitle());
        holder.date.setText(tickets.get(position).getDate());
        holder.location.setText(tickets.get(position).getLocation());

        Glide.with(context)
                .load("https://image.tmdb.org/t/p/w500" + tickets.get(position).getMovie().getImg())
                .into(holder.img);
    }

    @Override
    public int getItemCount() {
        return tickets.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, date, location;
        ImageView img;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.title_txt);
            img = itemView.findViewById(R.id.imageView);
            date = itemView.findViewById(R.id.date_txt);
            location = itemView.findViewById(R.id.location_txt);
        }
    }
}
