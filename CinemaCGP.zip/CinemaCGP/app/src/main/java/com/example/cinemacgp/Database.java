package com.example.cinemacgp;

import java.util.ArrayList;

public class Database {

    private static ArrayList<Ticket> database;

    private Database(){}

    public static ArrayList<Ticket> getDatabase(){
        if(database == null)
            database = new ArrayList<>();
        return database;
    }
}
